package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.TextViewCompat;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.Calendar;

public class List extends AppCompatActivity {

    private TextView txt;
    private String itemmName,ItemmQuantity,listViewP;
    private DatePickerDialog datePickerDialog;
    private Button dateButton,buttonn,pop;
    private ListView lv;
    ArrayList<String> arrayList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        lv = (ListView) findViewById(R.id.listvieew);
        pop = (Button) findViewById(R.id.button4);

        itemmName = getIntent().getStringExtra("list Item");
        ItemmQuantity = getIntent().getStringExtra("List Quantity");

        listViewP = itemmName + " (Quantity: " + ItemmQuantity +" )";

        arrayList = new ArrayList<String>();
        adapter = new ArrayAdapter<String>(List.this, android.R.layout.simple_list_item_1,arrayList);
        lv.setAdapter(adapter);
        arrayList.add(listViewP);
        adapter.notifyDataSetChanged();

        buttonn = findViewById(R.id.button5);

        buttonn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customDialog1();
            }
        });



        txt = findViewById(R.id.textView);

        String edditText = getIntent().getStringExtra("list Name");

        txt.setText(edditText);

        initDatePicker();

        dateButton = findViewById(R.id.datePickerButton);
        dateButton.setText(getTodaysDate());
    }

    public void onBtnClick(){
    pop.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

        }
    });
    }


    private void customDialog1(){

        androidx.appcompat.app.AlertDialog.Builder mydialog1 = new androidx.appcompat.app.AlertDialog.Builder(List.this);

        LayoutInflater inflater = LayoutInflater.from(List.this);
        View myview1 = inflater.inflate(R.layout.input_list_data,null);
        androidx.appcompat.app.AlertDialog dialog=mydialog1.create();
        dialog.setView(myview1);
        dialog.show();

        final EditText Itemname = myview1.findViewById(R.id.item_name);
        final EditText ItemQty = myview1.findViewById(R.id.item_qty);
        final Button addd = myview1.findViewById(R.id.Save1);

        addd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String edditTeext = Itemname.getText().toString();
                String eitText = ItemQty.getText().toString();

                if (edditTeext.matches("") || eitText.matches("")) {

                    Toast.makeText(List.this, "You can't leave input boxes empty", Toast.LENGTH_SHORT).show();
                    return;

                } else {

                    Intent intent = new Intent(getApplicationContext(), List.class);
                    intent.putExtra("list Item", edditTeext);
                    intent.putExtra("List Quantity", eitText);
                    startActivity(intent);
                }


            }
        });
    }

    private String getTodaysDate()
    {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        month = month + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    private void initDatePicker()
    {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day)
            {
                month = month + 1;
                String date = makeDateString(day, month, year);
                dateButton.setText(date);
            }
        };

        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        int style = AlertDialog.THEME_HOLO_LIGHT;

        datePickerDialog = new DatePickerDialog(this, style, dateSetListener, year, month, day);
        //datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());

    }

    private String makeDateString(int day, int month, int year)
    {
        return getMonthFormat(month) + " " + day + " " + year;
    }

    private String getMonthFormat(int month)
    {
        if(month == 1)
            return "JAN";
        if(month == 2)
            return "FEB";
        if(month == 3)
            return "MAR";
        if(month == 4)
            return "APR";
        if(month == 5)
            return "MAY";
        if(month == 6)
            return "JUN";
        if(month == 7)
            return "JUL";
        if(month == 8)
            return "AUG";
        if(month == 9)
            return "SEP";
        if(month == 10)
            return "OCT";
        if(month == 11)
            return "NOV";
        if(month == 12)
            return "DEC";

        //default should never happen
        return "JAN";
    }

    public void openDatePicker(View view)
    {
        datePickerDialog.show();
    }
}